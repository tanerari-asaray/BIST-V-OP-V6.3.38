# BIST–VİOP Build 668 güncellenmiş kaynak

**APK bu pakette bulunmaz.** Son kontrol sonuçları için önce `BUILD668-NIHAI-DOGRULAMA-RAPORU.md` dosyasını okuyun. Android kaynak kökü `android-v6323/` içindedir.
