# BIST/VİOP · V6.3.37 / Build 667

Fiyat yenileme tanılaması düzeltildi: eksik adres/anahtar, HTTP durumları ve veri sağlayıcısı hataları ayrıdır; aynı neden tek özette gösterilir. build/apk667-quote-diagnostics dalı. Paket kimliği Build 666 ile aynıdır; aynı sertifika ile güncellenir. Canlı Railway gateway BIST/VİOP fiyat kaynağına bağlı değildir; bu APK düzeltmesi sağlayıcı bağlantısı kurmaz.

Önceki Build 666 APK üretimi ve doğrulama kayıtları geçmiş dosyalarında korunur.

Güncel Android kaynağı **`android-v6323/`** dizinindedir. Klasör adındaki sayı uygulamanın güncel sürüm numarası değildir; sürüm kimliği `android-v6323/app/build.gradle.kts` içindedir. Depodaki diğer Android klasörleri, overlay'ler ve eski ZIP'ler tarihsel sürümlerdir; güncel kaynağın üzerine uygulanmaz.

Önceki kaynak geliştirme dalı `fix/deep-audit-no-apk`, inceleme kaydı [PR #2](https://github.com/ferittasbek-png/BIST-VIOP-V6.2.2/pull/2). Test ve kaynak raporları `audit/` altında bulunur. Gateway kaynağı ve testleri `server/` içindedir.

## APK üretmeden doğrulama

JDK 17, Android SDK Platform 35 ve projenin Gradle Wrapper'ı kullanılır:

```bash
cd android-v6323
./gradlew --no-daemon -I ../ci-source-only.init.gradle \
  :app:testDiagnosticUnitTest :app:compileDiagnosticAndroidTestKotlin \
  :app:processDiagnosticResources :app:lintDiagnostic
cd ..
python3 ci-verify-source-only.py
node --test server/tests/*.test.mjs
python3 server/build_railway_bundle.py --check
```

`ci-source-only.init.gradle` paketleme ve kurulum görevlerini çalıştırılmadan reddeder. Android test kaynaklarının derlenmesi, testlerin cihazda yürütüldüğü anlamına gelmez. Bu kaynak kontrolü modu APK/AAB üretmez. Yetkilendirilmiş Build 666 APK akışı ayrı çalışma dalında paketleme yapar.

Lisanslı canlı veri bağlantısı ve fiziksel cihaz doğrulaması tamamlanmadan üretime hazır veya canlı işlem doğrulanmış sonucu verilmez. Gizli API anahtarları kaynak koduna eklenmez.
